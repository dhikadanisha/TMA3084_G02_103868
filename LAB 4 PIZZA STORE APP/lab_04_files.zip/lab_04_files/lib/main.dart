import 'package:flutter/material.dart';

import 'detail_screen.dart';
import 'menu_screen.dart';
import 'order_summary.dart';

void main() => runApp(const PizzaStoreApp());

class PizzaStoreApp extends StatelessWidget {
  const PizzaStoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pizza Store',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.deepOrange, useMaterial3: true),
      initialRoute: 'menu',
      routes: {
        'menu': (context) => const MenuScreen(),
        'vegetable': (context) => const DetailScreen(
              title: 'Vegetable Pizza',
              imagePath: 'assets/images/vegetable_pizza.png',
              description:
                  'Fresh mushrooms, tomatoes and herbs on a crisp tomato base.',
            ),
        'cheese': (context) => const DetailScreen(
              title: 'Cheese Pizza',
              imagePath: 'assets/images/cheese_pizza.png',
              description:
                  'Classic mozzarella melted over a rich tomato sauce.',
            ),
        'fries': (context) => const DetailScreen(
              title: 'Box of Fries',
              imagePath: 'assets/images/fries.png',
              description: 'Golden, crispy fries served hot with a pinch of salt.',
            ),
        'order_summary': (context) => const OrderSummaryScreen(
              itemName: 'Vegetable Pizza',
              quantity: 2,
              unitPrice: 12.50,
            ),
      },
    );
  }
}
