import 'package:flutter/material.dart';

import 'order.dart';

class OrderSummaryScreen extends StatelessWidget {
  const OrderSummaryScreen({
    super.key,
    required this.itemName,
    required this.quantity,
    required this.unitPrice,
  });

  final String itemName;
  final int quantity;
  final double unitPrice;

  @override
  Widget build(BuildContext context) {
    final total = orderTotal(quantity, unitPrice);
    return Scaffold(
      appBar: AppBar(title: const Text('Order Summary')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Item: $itemName',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text('Quantity: $quantity',
                style: Theme.of(context).textTheme.titleMedium),
            const Divider(height: 32),
            Text(
              'Total: RM ${total.toStringAsFixed(2)}',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const Spacer(),
            OutlinedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Back'),
            ),
          ],
        ),
      ),
    );
  }
}
