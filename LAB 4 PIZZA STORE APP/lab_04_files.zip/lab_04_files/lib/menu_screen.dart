import 'package:flutter/material.dart';

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  static const _items = [
    ('Vegetable Pizza', 'vegetable'),
    ('Cheese Pizza', 'cheese'),
    ('Box of Fries', 'fries'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pizza Store'),
        actions: [
          IconButton(
            tooltip: 'Order summary',
            icon: const Icon(Icons.receipt_long),
            onPressed: () => Navigator.pushNamed(context, 'order_summary'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final (label, route) in _items)
            Card(
              color: Colors.orange,
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                title: Text(
                  label,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87,
                  ),
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.pushNamed(context, route),
              ),
            ),
        ],
      ),
    );
  }
}
