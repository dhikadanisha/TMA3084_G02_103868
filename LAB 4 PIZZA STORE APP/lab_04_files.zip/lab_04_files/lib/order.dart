/// Returns the total price (in RM) for [quantity] items at [unitPrice] each.
///
/// NOTE: If your lecturer supplied their own lib/order.dart, keep theirs and
/// delete this file. Adjust order_summary.dart to match its signature.
double orderTotal(int quantity, double unitPrice) => quantity * unitPrice;
