# Setup

1. `flutter create lab_04` (the project name MUST be lab_04 so imports work)
2. Copy `lib/`, `test/`, `docs/`, `.github/` and `assets/` from this folder into it
   (overwrite the generated `lib/main.dart`; delete the generated `test/widget_test.dart`).
3. Add the assets block from `pubspec_snippet.yaml` to `pubspec.yaml`.
4. `flutter pub get && flutter analyze && flutter test && flutter run`
