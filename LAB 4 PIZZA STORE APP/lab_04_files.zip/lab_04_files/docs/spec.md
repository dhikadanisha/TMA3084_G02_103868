# Order Summary Screen: Mini-Spec

1. **Purpose:** Show the customer a read-only summary of their order before they leave the screen.
2. **Inputs:** `itemName` (String), `quantity` (int), `unitPrice` (double, in RM), passed into `OrderSummaryScreen`.
3. **Output:** Text for the item name and quantity, plus the total as `Total: RM xx.xx` (two decimals), with a Back button.
4. **Rules:** The total must come from `orderTotal` in `lib/order.dart`; the Back button must use `Navigator.pop`; no other files are modified.
5. **Out of scope:** Editing the order, payment, discounts or tax, saving orders, and any networking.
6. **Check:** For Vegetable Pizza, quantity 2, unit price RM 12.50, the screen shows `Total: RM 25.00`, verified by `test/order_summary_test.dart`.
