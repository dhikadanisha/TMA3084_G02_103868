# Prompt for the AI (Vibe Coding Task 4)

I'm building a Flutter app called lab_04. Create ONE new file, `lib/order_summary.dart`,
containing a stateless widget `OrderSummaryScreen`.

Requirements:
- Constructor takes `itemName` (String), `quantity` (int), `unitPrice` (double).
- Import `lib/order.dart` and compute the total ONLY by calling
  `orderTotal(quantity, unitPrice)`. Do not recompute the price yourself.
- Show the item name, the quantity, and the total formatted as `Total: RM 25.00`
  (two decimals).
- Include a Back button that calls `Navigator.pop(context)`.
- Use Material widgets only, no extra packages.
- Do NOT modify any other file. It must pass `flutter analyze` with no issues.
- Return only the code for `lib/order_summary.dart`.
