# Lab 04 Logs (fill in with your real runs, then export to PDF or Word)

## LOGTEST: test runs
| Date | Test file | Command | Result | Notes |
|---|---|---|---|---|
| | test/pizza_store_test.dart | flutter test test/pizza_store_test.dart | | |
| | test/order_summary_test.dart | flutter test test/order_summary_test.dart | | |
| | all | flutter analyze && flutter test | | |

## LOGD: one bug you debugged
- **Date:**
- **Symptom:** (what you saw: error message / wrong behaviour)
- **Cause:** (why it happened)
- **Fix:** (what you changed)
- **Evidence:** (screenshot / test output after the fix)

## LOGAI (Entry AI-001)
- **AI tool used:**
- **Prompt:** (paste from docs/ai_prompt.md, or your edited version)
- **AI output:** (summary or paste of the code it gave)
- **Your changes:** (what you edited and why)
- **Test results:** (flutter analyze / flutter test output)
- **Decision:** Accept / Modify / Reject, and the reason
