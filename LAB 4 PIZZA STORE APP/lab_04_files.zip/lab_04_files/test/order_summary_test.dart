import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lab_04/order_summary.dart';

void main() {
  testWidgets('shows item, quantity and correct total (RM 25.00)',
      (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: OrderSummaryScreen(
        itemName: 'Vegetable Pizza',
        quantity: 2,
        unitPrice: 12.50,
      ),
    ));

    expect(find.text('Item: Vegetable Pizza'), findsOneWidget);
    expect(find.text('Quantity: 2'), findsOneWidget);
    expect(find.text('Total: RM 25.00'), findsOneWidget);
  });

  testWidgets('Back button pops the screen', (tester) async {
    await tester.pumpWidget(MaterialApp(
      home: Builder(
        builder: (context) => Scaffold(
          body: ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const OrderSummaryScreen(
                  itemName: 'Vegetable Pizza',
                  quantity: 2,
                  unitPrice: 12.50,
                ),
              ),
            ),
            child: const Text('Open'),
          ),
        ),
      ),
    ));

    await tester.tap(find.text('Open'));
    await tester.pumpAndSettle();
    expect(find.byType(OrderSummaryScreen), findsOneWidget);

    await tester.tap(find.text('Back'));
    await tester.pumpAndSettle();
    expect(find.byType(OrderSummaryScreen), findsNothing);
  });
}
